import bpy

bl_info = {
    "name": "toggle and xray",
    "author": "r.lumampao",
    "version": (1, 0),
    "blender": (2, 80, 0),
    "location": "View3D > Panel",
    "description": "toggle n cursor",
    "warning": "",
    "doc_url": "",
    "category": "toggle selection",
}


def toggle_tools(self, context):
    tool = context.workspace.tools.from_space_view3d_mode("EDIT_MESH", create=False)
    current_tool = tool.idname
    
    if current_tool == "builtin.select":
        bpy.ops.wm.tool_set_by_id(name="builtin.select_box")
    else:
        bpy.ops.wm.tool_set_by_id(name="builtin.select")

bpy.types.Scene.toggle_select_tools = bpy.props.BoolProperty(
    name="Toggle Select Tools",
    description="Toggle between select circle and select box tools",
    default=False,
    update=toggle_tools
)

class VIEW3D_PT_tools_custom(bpy.types.Panel):
    bl_label = "Change Cursor"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Redd"
    
    def draw(self, context):
        layout = self.layout
        tool = context.workspace.tools.from_space_view3d_mode("EDIT_MESH", create=False)
        current_tool = tool.idname
        
        if current_tool == "builtin.select":
            layout.prop(context.scene, "toggle_select_tools", toggle=True, text="Tweak")
        else:
            layout.prop(context.scene, "toggle_select_tools", toggle=True, text="Box Select")


class VIEW3D_OT_xray_toggle(bpy.types.Operator):
    """Toggle X-Ray and Change Cursor"""
    bl_idname = "view3d.xray_toggle"
    bl_label = "X-Ray Toggle"

    def execute(self, context):
        space = context.space_data
        space.shading.show_xray = not space.shading.show_xray

        # Change cursor to builtin.select_box
        bpy.ops.wm.tool_set_by_id(name="builtin.select_box")

        return {'FINISHED'}
class VIEW3D_PT_tools_custom1(bpy.types.Panel):
    bl_label = "Toggle Xray"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Redd"

    def draw(self, context):
        layout = self.layout
        col = layout.column(align=True)
        col.operator("view3d.xray_toggle", text="Toggle X-Ray")

def register():
    bpy.utils.register_class(VIEW3D_PT_tools_custom)
    bpy.utils.register_class(VIEW3D_OT_xray_toggle)
    bpy.utils.register_class(VIEW3D_PT_tools_custom1)
    
def unregister():
    bpy.utils.unregister_class(VIEW3D_PT_tools_custom)
    bpy.utils.register_class(VIEW3D_OT_xray_toggle)
    bpy.utils.register_class(VIEW3D_PT_tools_custom1)
    
if __name__ == "__main__":
    register()
